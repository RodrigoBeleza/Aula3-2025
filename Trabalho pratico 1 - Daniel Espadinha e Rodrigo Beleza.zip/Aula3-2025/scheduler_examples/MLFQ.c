#include "MLFQ.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "msg.h"
#include "debug.h"
#include "queue.h"

#ifndef MLFQ_Q_HIGH_MS
#define MLFQ_Q_HIGH_MS 500
#endif

#ifndef MLFQ_Q_LOW_MS
#define MLFQ_Q_LOW_MS 500
#endif

// Estado do escalonador
static uint32_t s_quantum_left_ms = 0;
static int s_cpu_level = -1;

//termina burst da tarefa atual
static void complete_current_burst(uint32_t current_time_ms, pcb_t **cpu_task) {
    if (*cpu_task == NULL) return;

    // Enviar DONE ao processo
    msg_t msg = {
        .pid = (*cpu_task)->pid,
        .request = PROCESS_REQUEST_DONE,
        .time_ms = current_time_ms
    };
    if (write((*cpu_task)->sockfd, &msg, sizeof(msg_t)) != sizeof(msg_t)) {
        perror("write");
    }

    DBG("[MLFQ] PID=%d terminou burst (t=%u ms)\n", (*cpu_task)->pid, current_time_ms);

    free(*cpu_task);
    *cpu_task = NULL;
    s_quantum_left_ms = 0;
    s_cpu_level = -1;
}

static void preempt_and_enqueue(pcb_t **cpu_task, queue_t *rq_target) {
    if (*cpu_task == NULL) return;

    // Não libertamos o PCB; volta para a ready queue
    enqueue_pcb(rq_target, *cpu_task);
    *cpu_task = NULL;
    s_quantum_left_ms = 0;

    s_cpu_level = -1;
}

//escolher próxima tarefa de acordo com prioridade
static void dispatch_next(queue_t *rq_high, queue_t *rq_low, pcb_t **cpu_task) {
    if (*cpu_task) return;

    pcb_t *next = dequeue_pcb(rq_high);
    if (next) {
        *cpu_task = next;
        s_cpu_level = 0;
        s_quantum_left_ms = MLFQ_Q_HIGH_MS;
        DBG("[MLFQ] Dispatch PID=%d (Nível=ALTA, Q=%u ms)\n", next->pid, s_quantum_left_ms);
        return;
    }

    next = dequeue_pcb(rq_low);
    if (next) {
        *cpu_task = next;
        s_cpu_level = 1;
        s_quantum_left_ms = MLFQ_Q_LOW_MS;
        DBG("[MLFQ] Dispatch PID=%d (Nível=BAIXA, Q=%u ms)\n", next->pid, s_quantum_left_ms);
        return;
    }

    s_cpu_level = -1;
    s_quantum_left_ms = 0;
}

void mlfq_scheduler(uint32_t current_time_ms,
                    queue_t *rq_high,
                    queue_t *rq_low,
                    pcb_t **cpu_task)
{
    //Se há tarefa na CPU, consumir um tick de CPU
    if (*cpu_task) {
        // Avança tempo de CPU deste burst
        (*cpu_task)->ellapsed_time_ms += TICKS_MS;

        // Consome quantum
        if (s_quantum_left_ms > TICKS_MS) {
            s_quantum_left_ms -= TICKS_MS;
        } else {
            s_quantum_left_ms = 0;
        }

        // Caso 1: burst terminou
        if ((*cpu_task)->ellapsed_time_ms >= (*cpu_task)->time_ms) {
            complete_current_burst(current_time_ms, cpu_task);
        }
        // Caso 2: preempt por chegada de trabalho de maior prioridade
        else if (s_cpu_level == 1 && rq_high->head != NULL) {
            // Tarefa atual está na Fila BAIXA e chegaram tarefas na ALTA - preempt
            DBG("[MLFQ] Preempção: chegou trabalho na Fila ALTA; PID=%d volta à Baixa\n",
                (*cpu_task)->pid);
            preempt_and_enqueue(cpu_task, rq_low);
        }
        // Caso 3: quantum esgotou - re-enfileirar/demover conforme nível
        else if (s_quantum_left_ms == 0) {
            if (s_cpu_level == 0) {
                // Fila Alta: não terminou o burst - despromove para Baixa
                DBG("[MLFQ] Quantum esgotado (ALTA): PID=%d despromovido para Baixa\n",
                    (*cpu_task)->pid);
                preempt_and_enqueue(cpu_task, rq_low);
            } else {
                // Fila Baixa: RR - volta para o fim da Baixa
                DBG("[MLFQ] Quantum esgotado (BAIXA): PID=%d re-enfileirado na Baixa\n",
                    (*cpu_task)->pid);
                preempt_and_enqueue(cpu_task, rq_low);
            }
        }
    }

    //Se a CPU ficou livre (ou estava ociosa), despachar próxima tarefa
    if (*cpu_task == NULL) {
        dispatch_next(rq_high, rq_low, cpu_task);
    }
}
