#include "RR.h"
#include "queue.h"
#include "msg.h"
#include <stdio.h>
#include <unistd.h>

#define TIME_QUANTUM 500

static uint32_t quantum_counter = 0;

void rr_scheduler(uint32_t current_time_ms, queue_t *rq, pcb_t **cpu_task) {
    if (*cpu_task) {
        // Atualiza tempo decorrido
        (*cpu_task)->ellapsed_time_ms += TICKS_MS;
        quantum_counter += TICKS_MS;

        // Se terminou
        if ((*cpu_task)->ellapsed_time_ms >= (*cpu_task)->time_ms) {
            msg_t msg = {
                .pid = (*cpu_task)->pid,
                .request = PROCESS_REQUEST_DONE,
                .time_ms = current_time_ms
            };
            if (write((*cpu_task)->sockfd, &msg, sizeof(msg_t)) != sizeof(msg_t)) {
                perror("write");
            }
            free(*cpu_task);
            *cpu_task = NULL;
            quantum_counter = 0;
        }
        // Se acabou o quantum - reencaminha para a fila
        else if (quantum_counter >= TIME_QUANTUM) {
            enqueue_pcb(rq, *cpu_task);  // volta para o fim da fila
            *cpu_task = NULL;
            quantum_counter = 0;
        }
    }

    // Se CPU livre - pega no próximo processo da fila
    if (*cpu_task == NULL) {
        *cpu_task = dequeue_pcb(rq);
        if (*cpu_task) {
            printf("Time %u ms: Running process %d (remaining %u ms)\n",
                   current_time_ms,
                   (*cpu_task)->pid,
                   (*cpu_task)->time_ms - (*cpu_task)->ellapsed_time_ms);
        }
    }
}
