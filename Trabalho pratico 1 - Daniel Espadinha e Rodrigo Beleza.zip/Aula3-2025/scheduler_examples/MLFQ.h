#ifndef MLFQ_H
#define MLFQ_H

#include <stdint.h>
#include "queue.h"

void mlfq_scheduler(uint32_t current_time_ms,
                    queue_t *rq_high,
                    queue_t *rq_low,
                    pcb_t **cpu_task);

#endif // MLFQ_H
